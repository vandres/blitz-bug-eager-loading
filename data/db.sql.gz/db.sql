-- MySQL dump 10.13  Distrib 8.0.33, for Linux (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ihshepdvzjytyscqidbgidhpklwrjxynghqj` (`ownerId`),
  CONSTRAINT `fk_ihshepdvzjytyscqidbgidhpklwrjxynghqj` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pzmohuyilxhwsvodhtsfcelawhoykhcycwme` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpdfyvylipjqiuylyovhehcujmqhyvskbdas` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_syxwtyaafyrlgpnsebsclsqjsjfwshprlmmb` (`dateRead`),
  KEY `fk_sxmssaakfpliqbschlfhibbfhefqxkhlgsnp` (`pluginId`),
  CONSTRAINT `fk_hfecslevsscuieksmswrabrvushndufthmlq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sxmssaakfpliqbschlfhibbfhefqxkhlgsnp` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xecgnhshdyhjomttafpbqiwzvkmlenjqhefr` (`sessionId`,`volumeId`),
  KEY `idx_lqmieknzrbrgwlsggwaprziazpsghoieglln` (`volumeId`),
  CONSTRAINT `fk_lphsgcuddhpqzenrhinifhyhzeizuwvgdjon` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mcfgzgndzscfpxgkpcolcnovtioyzbywgrlf` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vtigitfarfmwrqzxhvioudbcfozlgblylkrn` (`filename`,`folderId`),
  KEY `idx_zjcnorzprnybtblxotyrhlcwexghqpyfibou` (`folderId`),
  KEY `idx_rbsfjtdyhjfacoepiujucfbbmgtgfttdzjmz` (`volumeId`),
  KEY `fk_nyidozolpiztqrmrmtbkzivaxbqpbvpafflo` (`uploaderId`),
  CONSTRAINT `fk_egkjjbonmqccworaiahgieorhdqprnwofhyl` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nyidozolpiztqrmrmtbkzivaxbqpbvpafflo` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pmdrrfruqfmhatofqukdxcgefriyfojgwbzm` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ytjpapskiawqkpaacnkidsmeoivmraiwonpo` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_caches`
--

DROP TABLE IF EXISTS `blitz_caches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_caches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `siteId` int NOT NULL,
  `uri` varchar(255) NOT NULL,
  `paginate` int DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gbhxqivuykkijnngwztjimqisdzabosapwgl` (`siteId`,`uri`),
  KEY `idx_iivfjlesusbyctfyaqveadrcikqsyhxpoudq` (`expiryDate`),
  CONSTRAINT `fk_kieiroimkcarcumylhknqrvtfascufymzpla` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_caches`
--

LOCK TABLES `blitz_caches` WRITE;
/*!40000 ALTER TABLE `blitz_caches` DISABLE KEYS */;
INSERT INTO `blitz_caches` VALUES (7,1,'page/disclaimer',NULL,NULL),(8,1,'',NULL,NULL),(9,1,'page/privacy',NULL,NULL);
/*!40000 ALTER TABLE `blitz_caches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_cachetags`
--

DROP TABLE IF EXISTS `blitz_cachetags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_cachetags` (
  `cacheId` int NOT NULL,
  `tag` varchar(255) NOT NULL,
  PRIMARY KEY (`cacheId`,`tag`),
  KEY `idx_hpzmfpkfonaapewhojdeweauzxmpvsrjfcql` (`tag`),
  CONSTRAINT `fk_fidurqyyafvqcxudvocwammgvovksmmdakxl` FOREIGN KEY (`cacheId`) REFERENCES `blitz_caches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_cachetags`
--

LOCK TABLES `blitz_cachetags` WRITE;
/*!40000 ALTER TABLE `blitz_cachetags` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_cachetags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_driverdata`
--

DROP TABLE IF EXISTS `blitz_driverdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_driverdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `driver` varchar(255) NOT NULL,
  `data` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_driverdata`
--

LOCK TABLES `blitz_driverdata` WRITE;
/*!40000 ALTER TABLE `blitz_driverdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_driverdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementcaches`
--

DROP TABLE IF EXISTS `blitz_elementcaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementcaches` (
  `cacheId` int NOT NULL,
  `elementId` int NOT NULL,
  PRIMARY KEY (`cacheId`,`elementId`),
  KEY `fk_sgdizaxtjsmhaycobcqlxceghbhidzqzrday` (`elementId`),
  CONSTRAINT `fk_mmijdjzqsigsdzuntizqrpgasanexjslavrx` FOREIGN KEY (`cacheId`) REFERENCES `blitz_caches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_sgdizaxtjsmhaycobcqlxceghbhidzqzrday` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementcaches`
--

LOCK TABLES `blitz_elementcaches` WRITE;
/*!40000 ALTER TABLE `blitz_elementcaches` DISABLE KEYS */;
INSERT INTO `blitz_elementcaches` VALUES (8,2),(7,5),(8,5),(9,5),(7,10),(8,10),(9,10),(7,12),(8,12),(9,12);
/*!40000 ALTER TABLE `blitz_elementcaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementexpirydates`
--

DROP TABLE IF EXISTS `blitz_elementexpirydates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementexpirydates` (
  `elementId` int NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`),
  UNIQUE KEY `idx_icsmtflwmtporqfltpcdtgtirvrujkkzlwwb` (`elementId`),
  KEY `idx_rzbwdxzperjojlfcqfjqtxjwbqcyninxbgds` (`expiryDate`),
  CONSTRAINT `fk_rjrobnxdagypkesaxxgzrtbybzgpwbezfhxv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementexpirydates`
--

LOCK TABLES `blitz_elementexpirydates` WRITE;
/*!40000 ALTER TABLE `blitz_elementexpirydates` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementexpirydates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementfieldcaches`
--

DROP TABLE IF EXISTS `blitz_elementfieldcaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementfieldcaches` (
  `cacheId` int NOT NULL,
  `elementId` int NOT NULL,
  `fieldId` int NOT NULL,
  PRIMARY KEY (`cacheId`,`elementId`,`fieldId`),
  KEY `fk_qqknwwmrmdchljuitwwhhobucetzbidszkvs` (`elementId`),
  KEY `fk_mpfpydtjbwiuwmzkqpukkrvwluckmuuhptio` (`fieldId`),
  CONSTRAINT `fk_mpfpydtjbwiuwmzkqpukkrvwluckmuuhptio` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qqknwwmrmdchljuitwwhhobucetzbidszkvs` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wyhkjgyebmkigihkzvxakwbdkyoqgqnxdwim` FOREIGN KEY (`cacheId`) REFERENCES `blitz_caches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementfieldcaches`
--

LOCK TABLES `blitz_elementfieldcaches` WRITE;
/*!40000 ALTER TABLE `blitz_elementfieldcaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementfieldcaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementqueries`
--

DROP TABLE IF EXISTS `blitz_elementqueries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementqueries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `index` bigint NOT NULL,
  `type` varchar(255) NOT NULL,
  `params` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_roxzaoslpkkovdtvkeinxcexhchsvmxzjxhj` (`index`),
  KEY `idx_ojgmncqijjspwdaoytcsspeaswtpeplxxini` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementqueries`
--

LOCK TABLES `blitz_elementqueries` WRITE;
/*!40000 ALTER TABLE `blitz_elementqueries` DISABLE KEYS */;
INSERT INTO `blitz_elementqueries` VALUES (1,3263654465,'craft\\elements\\Entry','{\"sectionId\":2,\"siteId\":1}');
/*!40000 ALTER TABLE `blitz_elementqueries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementqueryattributes`
--

DROP TABLE IF EXISTS `blitz_elementqueryattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementqueryattributes` (
  `queryId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  PRIMARY KEY (`queryId`,`attribute`),
  CONSTRAINT `fk_orlzscwjoeekiydxssjrptjkvxbmrcworxzz` FOREIGN KEY (`queryId`) REFERENCES `blitz_elementqueries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementqueryattributes`
--

LOCK TABLES `blitz_elementqueryattributes` WRITE;
/*!40000 ALTER TABLE `blitz_elementqueryattributes` DISABLE KEYS */;
INSERT INTO `blitz_elementqueryattributes` VALUES (1,'postDate');
/*!40000 ALTER TABLE `blitz_elementqueryattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementquerycaches`
--

DROP TABLE IF EXISTS `blitz_elementquerycaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementquerycaches` (
  `cacheId` int NOT NULL,
  `queryId` int NOT NULL,
  PRIMARY KEY (`cacheId`,`queryId`),
  KEY `fk_ywfnzjwdxpvyuxzkgqlgjmlznkhlaumyissv` (`queryId`),
  CONSTRAINT `fk_vzmtadunkglxygxyxgbzbvlqqbthmayyfmop` FOREIGN KEY (`cacheId`) REFERENCES `blitz_caches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ywfnzjwdxpvyuxzkgqlgjmlznkhlaumyissv` FOREIGN KEY (`queryId`) REFERENCES `blitz_elementqueries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementquerycaches`
--

LOCK TABLES `blitz_elementquerycaches` WRITE;
/*!40000 ALTER TABLE `blitz_elementquerycaches` DISABLE KEYS */;
INSERT INTO `blitz_elementquerycaches` VALUES (7,1),(8,1),(9,1);
/*!40000 ALTER TABLE `blitz_elementquerycaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementqueryfields`
--

DROP TABLE IF EXISTS `blitz_elementqueryfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementqueryfields` (
  `queryId` int NOT NULL,
  `fieldId` int NOT NULL,
  PRIMARY KEY (`queryId`,`fieldId`),
  KEY `fk_jbpjnafuswnibzfzsvmqxkagezniplhxxfeh` (`fieldId`),
  CONSTRAINT `fk_jbpjnafuswnibzfzsvmqxkagezniplhxxfeh` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qemrgdrreinkajnkngesjfafuphdypprauhe` FOREIGN KEY (`queryId`) REFERENCES `blitz_elementqueries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementqueryfields`
--

LOCK TABLES `blitz_elementqueryfields` WRITE;
/*!40000 ALTER TABLE `blitz_elementqueryfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementqueryfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementquerysources`
--

DROP TABLE IF EXISTS `blitz_elementquerysources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementquerysources` (
  `queryId` int NOT NULL,
  `sourceId` int NOT NULL,
  PRIMARY KEY (`queryId`,`sourceId`),
  CONSTRAINT `fk_ztofhoxnxxtwtocmtapqkkwwmwlhpdcsikwq` FOREIGN KEY (`queryId`) REFERENCES `blitz_elementqueries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementquerysources`
--

LOCK TABLES `blitz_elementquerysources` WRITE;
/*!40000 ALTER TABLE `blitz_elementquerysources` DISABLE KEYS */;
INSERT INTO `blitz_elementquerysources` VALUES (1,2);
/*!40000 ALTER TABLE `blitz_elementquerysources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_hints`
--

DROP TABLE IF EXISTS `blitz_hints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_hints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `template` varchar(255) NOT NULL,
  `routeVariable` varchar(255) NOT NULL,
  `line` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_axkypnekgsaoyicsjmqozckjldajryewwwmh` (`fieldId`,`template`,`routeVariable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_hints`
--

LOCK TABLES `blitz_hints` WRITE;
/*!40000 ALTER TABLE `blitz_hints` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_hints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_includes`
--

DROP TABLE IF EXISTS `blitz_includes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_includes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `index` bigint NOT NULL,
  `siteId` int NOT NULL,
  `template` varchar(255) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qalwmovgobqkqssrvdjzeaumeqzxbmmjjmtw` (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_includes`
--

LOCK TABLES `blitz_includes` WRITE;
/*!40000 ALTER TABLE `blitz_includes` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_includes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_ssiincludecaches`
--

DROP TABLE IF EXISTS `blitz_ssiincludecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_ssiincludecaches` (
  `cacheId` int NOT NULL,
  `includeId` int NOT NULL,
  PRIMARY KEY (`cacheId`,`includeId`),
  KEY `fk_telgimilrkcvzpcbpqffwiivomjynpwvgmjz` (`includeId`),
  CONSTRAINT `fk_telgimilrkcvzpcbpqffwiivomjynpwvgmjz` FOREIGN KEY (`includeId`) REFERENCES `blitz_includes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ynzqyhksphmzakjwfsuntrrpfsfhqhecbkmf` FOREIGN KEY (`cacheId`) REFERENCES `blitz_caches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_ssiincludecaches`
--

LOCK TABLES `blitz_ssiincludecaches` WRITE;
/*!40000 ALTER TABLE `blitz_ssiincludecaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_ssiincludecaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rhprffwkctfstqteumxplwrqziwdqpurowgd` (`groupId`),
  KEY `fk_asxkiirrdbzqytvyhsvipgnxihvzbtecgvko` (`parentId`),
  CONSTRAINT `fk_asxkiirrdbzqytvyhsvipgnxihvzbtecgvko` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ekrniilzzbmnqxinxijswiqsorhmbiyocnty` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sspkofvifopsjagcaueeudxhqyflrprcwzdn` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_swasjhwbyvptgmzqhpzhxydtfrakaaxmxfvr` (`name`),
  KEY `idx_vbjtrpohpxggeonmixullnttcdhiystkfqdc` (`handle`),
  KEY `idx_xtuefgdnbgdhoowtthkzfknfympmplcyuczi` (`structureId`),
  KEY `idx_csitcwmgmvjzbcztxevzmbrxlxmpseyrmilo` (`fieldLayoutId`),
  KEY `idx_vxsrdgtaglhdpenmpieewiaudidnqsqqrmrc` (`dateDeleted`),
  CONSTRAINT `fk_byqvjpjzhdtadzznqnljioayzfrqurdcscfp` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_grvjvazimeaxcctttqvnisauyrfyykgarayg` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tonfjcurkfgonyswykmuhlxfdezprjhjolgm` (`groupId`,`siteId`),
  KEY `idx_jonigdxtnkauxoxpanbvykbloimzcoxupqde` (`siteId`),
  CONSTRAINT `fk_lqwbzfzgaqcthzzvytinbnqgemeighbsuwyx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qznmezmrfqrqqhhzqmspxknccehqdtujsopg` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_qzkmbdcgcflknzknwkihsmdtyvxbpyfpgzsm` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_klluomhvlchkpzfbhwqxjipomtgyuvpladbf` (`siteId`),
  KEY `fk_gvafahdosofsakoxgryrtngcihscpckyegcf` (`userId`),
  CONSTRAINT `fk_futwwzhcyiwxumsmvtxhypnuqbzaozoaaapo` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_gvafahdosofsakoxgryrtngcihscpckyegcf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_klluomhvlchkpzfbhwqxjipomtgyuvpladbf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (8,1,'postDate','2023-11-18 19:43:55',0,1),(8,1,'slug','2023-11-18 19:43:55',0,1),(8,1,'title','2023-11-18 19:43:55',0,1),(8,1,'uri','2023-11-18 19:43:55',0,1),(10,1,'postDate','2023-11-18 19:44:00',0,1),(10,1,'slug','2023-11-18 19:44:00',0,1),(10,1,'title','2023-11-18 19:47:31',0,1),(10,1,'uri','2023-11-18 19:44:00',0,1),(12,1,'postDate','2023-11-18 19:44:04',0,1),(12,1,'slug','2023-11-18 19:44:04',0,1),(12,1,'title','2023-11-18 19:44:04',0,1),(12,1,'uri','2023-11-18 19:44:04',0,1),(14,1,'postDate','2023-11-18 19:44:08',0,1),(14,1,'slug','2023-11-18 19:44:08',0,1),(14,1,'title','2023-11-18 19:44:08',0,1),(14,1,'uri','2023-11-18 19:44:08',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_sejooosorpgspmrnxbvdkuxwpndrkntipabh` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_dddycmnwettfstepbdvlruisgyiugfxscsvl` (`siteId`),
  KEY `fk_kjqggbkzvyeinsyvcqqpzgradulogmsotgxe` (`fieldId`),
  KEY `fk_hamsyzedvetrykrglpxebmqlstnsqjfgfkeh` (`userId`),
  CONSTRAINT `fk_dddycmnwettfstepbdvlruisgyiugfxscsvl` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_gnekknkpkddkvxveynekeiariehbkjashjvz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hamsyzedvetrykrglpxebmqlstnsqjfgfkeh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_kjqggbkzvyeinsyvcqqpzgradulogmsotgxe` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (5,1,1,'2023-11-18 19:47:18',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hqehfimspqtqcxhslvlclzihvzhytxjytusu` (`elementId`,`siteId`),
  KEY `idx_yvvnzdymbdjiuegguljcsjzubotjvtordgza` (`siteId`),
  KEY `idx_ealzyptefrfsvmrgciymfyblpyqwezlqpbcm` (`title`),
  CONSTRAINT `fk_efsetkibxzprukguelcmgnmltojtxzlntpyk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kepsywhnqhgacwxfwzbwhzturemawuooyezk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,1,1,NULL,'2023-11-18 19:34:57','2023-11-18 19:34:57','19216eb3-f681-43c0-9726-15ca72ef4b9c'),(2,2,1,'Home','2023-11-18 19:42:37','2023-11-18 19:42:37','a1e1d048-22aa-494b-9d9e-ca711cd79072'),(3,3,1,'Home','2023-11-18 19:42:37','2023-11-18 19:42:37','9d5057e1-88ce-4be6-8b5f-cbfbe5d55a50'),(4,4,1,'Home','2023-11-18 19:42:37','2023-11-18 19:42:37','7784467f-f8bb-4ba9-9c0a-4f32f55d1c12'),(5,5,1,'Header','2023-11-18 19:42:58','2023-11-18 19:47:32','6e0d0ac2-54b5-4298-a4c7-d1816f8aa149'),(6,6,1,'Header','2023-11-18 19:42:58','2023-11-18 19:42:58','c294cf2f-dfe8-4ee1-bb1a-cb18376548e0'),(7,7,1,'Header','2023-11-18 19:42:58','2023-11-18 19:42:58','50108ff0-a35d-4407-84a9-121f97abf807'),(8,8,1,'Terms','2023-11-18 19:43:53','2023-11-18 19:43:55','c6f6d0be-8885-4e24-afd9-faca829d8e95'),(9,9,1,'Terms','2023-11-18 19:43:55','2023-11-18 19:43:55','27b57dcd-b6ed-48d5-a019-4a3ef4a89fe3'),(10,10,1,'Disclaimer','2023-11-18 19:43:57','2023-11-18 19:47:31','a0b36a45-d2fa-4a29-91d4-43fb130bdd5d'),(11,11,1,'Disclaimer','2023-11-18 19:44:00','2023-11-18 19:44:00','bf20c1bc-4b95-40e4-af85-d1aeef526887'),(12,12,1,'Privacy','2023-11-18 19:44:01','2023-11-18 19:44:04','c29ec10e-695c-4348-9864-5b35200712bd'),(13,13,1,'Privacy','2023-11-18 19:44:04','2023-11-18 19:44:04','191b209f-fd4b-41cd-a7dc-58c4214066ac'),(14,14,1,'FAQ','2023-11-18 19:44:05','2023-11-18 19:44:08','0cf74205-05f3-44b0-b8f1-b6f78495ae45'),(15,15,1,'FAQ','2023-11-18 19:44:08','2023-11-18 19:44:08','80c5d40c-ed40-4ae9-86c7-321cb0777013'),(16,16,1,'Header','2023-11-18 19:44:20','2023-11-18 19:44:20','b649c574-d13f-4a1e-9f5a-8077aacfa6b7'),(18,18,1,'Header','2023-11-18 19:45:28','2023-11-18 19:45:28','e21b01f6-e0e3-4928-b401-6b1dbcb8a0d2'),(20,20,1,'Header','2023-11-18 19:46:20','2023-11-18 19:46:20','ec4f71a2-84e0-48ba-9438-057da341b9f1'),(22,22,1,'erDisclaimer','2023-11-18 19:46:51','2023-11-18 19:46:51','b663456a-f28e-4d09-b20e-108fff2f1296'),(23,23,1,'Header','2023-11-18 19:46:57','2023-11-18 19:46:57','cca78ac5-39c8-49c4-abf7-e12920b4afa6'),(25,25,1,'Header','2023-11-18 19:47:18','2023-11-18 19:47:18','7241a728-87c3-4efb-baf9-6914462931ce'),(27,27,1,'Disclaimer','2023-11-18 19:47:31','2023-11-18 19:47:31','b9681eea-41fb-4e18-88b2-e25a905ef36c'),(28,28,1,'Header','2023-11-18 19:47:32','2023-11-18 19:47:32','9c8186f1-b3ca-4f0b-a582-90dcbe41e138');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_colsqeztlwbnuaxicvumnmrvcnbcrvqamcrk` (`userId`),
  CONSTRAINT `fk_colsqeztlwbnuaxicvumnmrvcnbcrvqamcrk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_glzqdiwbqpxbgpmcalkoragjnddrotpljbkw` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_hbinqypvhfuwbbdbjbbpzuhtbfwsgdjtzszr` (`creatorId`,`provisional`),
  KEY `idx_axwdjlpxcvigljqhgdcfzotgoospmulthvvt` (`saved`),
  KEY `fk_onoprgcvtiagiljxlmyxzrogxkjtyduwnidp` (`canonicalId`),
  CONSTRAINT `fk_onoprgcvtiagiljxlmyxzrogxkjtyduwnidp` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_subxdnjnqcungmzjyussbbpqxgsnizzcwaxm` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_edfetunhdjikectdficwkvlsmmbplunxiiou` (`elementId`,`timestamp`,`userId`),
  KEY `fk_zlwsighlnkqyvilstqqfduengbfbrqbkhcrr` (`userId`),
  KEY `fk_nwcxpcrpogsrjfihxgomykclaqavyoxlkhca` (`siteId`),
  KEY `fk_qzhefolzauahyiosywfbhrrdeyfdacfnjuxq` (`draftId`),
  CONSTRAINT `fk_nwcxpcrpogsrjfihxgomykclaqavyoxlkhca` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qzhefolzauahyiosywfbhrrdeyfdacfnjuxq` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ubrqsgwystuuvwyzfnlaryngigkpejcoefnw` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zlwsighlnkqyvilstqqfduengbfbrqbkhcrr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (5,1,1,NULL,'edit','2023-11-18 19:47:16'),(5,1,1,NULL,'save','2023-11-18 19:47:32'),(8,1,1,NULL,'save','2023-11-18 19:43:55'),(10,1,1,NULL,'edit','2023-11-18 19:47:31'),(10,1,1,NULL,'save','2023-11-18 19:47:31'),(12,1,1,NULL,'save','2023-11-18 19:44:04'),(14,1,1,NULL,'save','2023-11-18 19:44:08');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_urtasjiyejttjuyspflwaeckvwbkfogwrrgb` (`dateDeleted`),
  KEY `idx_ahcfnipbcwiwmvmhznzvftdkwtipcycvtahm` (`fieldLayoutId`),
  KEY `idx_hfzlfnwyqawneamhenmpejfxdvezxspbutst` (`type`),
  KEY `idx_vysydedplhrfmllsfpellhqazycdkhndqahq` (`enabled`),
  KEY `idx_rhzyclpepbrsddhismddlgrqunhjwqksindz` (`canonicalId`),
  KEY `idx_glvlddxeezfkzzokfjopzhlfxxazdntdujhd` (`archived`,`dateCreated`),
  KEY `idx_sqmvnqlvuqhenahziizyrhwcpudngbepaosz` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_dhpylmmsyikjtvmktoitkhilwtwnevphpnqr` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_zdggkqjtvohwtjzptttfnitlbbwycdqddloc` (`draftId`),
  KEY `fk_xqxyuhaelzuvxqfnkamqwbahdcieriqvtdts` (`revisionId`),
  CONSTRAINT `fk_eybqtrrhvnxwkvidhfwamekdujximhmuqvql` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xqxyuhaelzuvxqfnkamqwbahdcieriqvtdts` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zdggkqjtvohwtjzptttfnitlbbwycdqddloc` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zigqggstjxivdqypvxhnofmkwcfsscuaoqqo` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2023-11-18 19:34:57','2023-11-18 19:34:57',NULL,NULL,'65b14eb3-bcf4-464f-8d6e-64a0a5de1d34'),(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-11-18 19:42:37','2023-11-18 19:42:37',NULL,NULL,'08de27e1-b6dc-4ae1-94d7-bd6f1211b53a'),(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2023-11-18 19:42:37','2023-11-18 19:42:37',NULL,NULL,'6320fe79-4839-4a68-aae9-7e174c6a3793'),(4,2,NULL,2,1,'craft\\elements\\Entry',1,0,'2023-11-18 19:42:37','2023-11-18 19:42:37',NULL,NULL,'c0020e69-64e5-42c4-b319-e3bd73ea21ba'),(5,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2023-11-18 19:42:58','2023-11-18 19:47:32',NULL,NULL,'d9d2cfb1-6a41-42dd-8098-9d984fdc085c'),(6,5,NULL,3,2,'craft\\elements\\Entry',1,0,'2023-11-18 19:42:58','2023-11-18 19:42:58',NULL,NULL,'9c8337a5-1b66-409a-8399-87c20b6456dd'),(7,5,NULL,4,2,'craft\\elements\\Entry',1,0,'2023-11-18 19:42:58','2023-11-18 19:42:58',NULL,NULL,'1be0e4f5-4d01-43b6-9b9c-154cebcc206f'),(8,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-18 19:43:53','2023-11-18 19:43:55',NULL,NULL,'21a23eda-4a09-4e26-b3d5-6a3439f8cf54'),(9,8,NULL,5,3,'craft\\elements\\Entry',1,0,'2023-11-18 19:43:55','2023-11-18 19:43:55',NULL,NULL,'b31dfef9-ff17-4e8c-98a2-aeb71bc202d4'),(10,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-18 19:43:57','2023-11-18 19:47:31',NULL,NULL,'fafb45ca-1755-4ca1-aa5a-d137bb2c2956'),(11,10,NULL,6,3,'craft\\elements\\Entry',1,0,'2023-11-18 19:44:00','2023-11-18 19:44:00',NULL,NULL,'3eb3124a-4225-4ab7-81f6-d0f96f9073d9'),(12,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-18 19:44:01','2023-11-18 19:44:04',NULL,NULL,'63bb520c-6613-40c2-9dbb-6a66e4f2f9e0'),(13,12,NULL,7,3,'craft\\elements\\Entry',1,0,'2023-11-18 19:44:04','2023-11-18 19:44:04',NULL,NULL,'12daf89f-fa18-4423-abe0-493f04104279'),(14,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-18 19:44:05','2023-11-18 19:44:08',NULL,NULL,'bf649645-8d61-4106-bc16-9175dcc9deb5'),(15,14,NULL,8,3,'craft\\elements\\Entry',1,0,'2023-11-18 19:44:08','2023-11-18 19:44:08',NULL,NULL,'2547a1a6-3a24-4d13-902c-b665507a80aa'),(16,5,NULL,9,2,'craft\\elements\\Entry',1,0,'2023-11-18 19:44:20','2023-11-18 19:44:20',NULL,NULL,'4f42ab07-7688-41a5-9d93-814812f3f7fc'),(18,5,NULL,10,2,'craft\\elements\\Entry',1,0,'2023-11-18 19:45:28','2023-11-18 19:45:28',NULL,NULL,'e19721e9-17d2-4ac4-a722-b5f4cb510133'),(20,5,NULL,11,2,'craft\\elements\\Entry',1,0,'2023-11-18 19:46:20','2023-11-18 19:46:20',NULL,NULL,'e43e6e8c-241f-4ab0-a5d8-f62ee2dcd302'),(22,10,NULL,12,3,'craft\\elements\\Entry',1,0,'2023-11-18 19:46:51','2023-11-18 19:46:51',NULL,NULL,'a6859d66-fad7-4610-8f4c-c71a3ed3c76b'),(23,5,NULL,13,2,'craft\\elements\\Entry',1,0,'2023-11-18 19:46:57','2023-11-18 19:46:57',NULL,NULL,'7ef917c1-0e06-4787-8b12-6859fc9cd642'),(25,5,NULL,14,2,'craft\\elements\\Entry',1,0,'2023-11-18 19:47:18','2023-11-18 19:47:18',NULL,NULL,'8621e37b-ec75-495d-baac-f6befe034c65'),(27,10,NULL,15,3,'craft\\elements\\Entry',1,0,'2023-11-18 19:47:31','2023-11-18 19:47:31',NULL,NULL,'6d601327-be5d-4af5-909b-7ad8db934445'),(28,5,NULL,16,2,'craft\\elements\\Entry',1,0,'2023-11-18 19:47:32','2023-11-18 19:47:32',NULL,NULL,'0a055f53-99c6-4125-8aec-372bf4f1d610');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ebytoodxqkfbphbfgqejkdrrpmxxavqymvpx` (`elementId`,`siteId`),
  KEY `idx_wrremfwanupbybgscvnmcynpfhxwvkfsrrvo` (`siteId`),
  KEY `idx_gxwxnuvlwyqinqmsuictuwfjkkortfjpindf` (`slug`,`siteId`),
  KEY `idx_nowryucppaqsrvufqvwzowwyjfxedjohuiwz` (`enabled`),
  KEY `idx_niltwbvzgqjvvbtpwsaoazbkqngisvlbtoyr` (`uri`,`siteId`),
  CONSTRAINT `fk_apvowlwiwyonrnvnkjsfqlbhrgujftuojeel` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_azozoxfwhqpuboxcxlynteiosznzfbcagmrz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2023-11-18 19:34:57','2023-11-18 19:34:57','833f850a-d39f-45a0-8a35-2e9316a93f8b'),(2,2,1,'home','__home__',1,'2023-11-18 19:42:37','2023-11-18 19:42:37','26cabb4d-d545-4130-8966-a339cc0dc751'),(3,3,1,'home','__home__',1,'2023-11-18 19:42:37','2023-11-18 19:42:37','cb0205b0-ea28-4dfc-89f4-13b6b6654736'),(4,4,1,'home','__home__',1,'2023-11-18 19:42:37','2023-11-18 19:42:37','faf5c12a-0ffb-4c89-8b80-4282428c1e78'),(5,5,1,'header',NULL,1,'2023-11-18 19:42:58','2023-11-18 19:42:58','8ad9c04f-aa7d-4be8-9653-66cf088358c0'),(6,6,1,'header',NULL,1,'2023-11-18 19:42:58','2023-11-18 19:42:58','42388ee7-ef57-4079-8064-606b9d857544'),(7,7,1,'header',NULL,1,'2023-11-18 19:42:58','2023-11-18 19:42:58','ec16d1a0-26a8-4701-97a8-279d1861f332'),(8,8,1,'terms','page/terms',1,'2023-11-18 19:43:53','2023-11-18 19:44:46','9b7e6249-150b-4f9e-8513-78f28c1bc7e1'),(9,9,1,'terms','page/terms',1,'2023-11-18 19:43:55','2023-11-18 19:43:55','85825bbd-7970-4b55-9910-41acdbc262ef'),(10,10,1,'disclaimer','page/disclaimer',1,'2023-11-18 19:43:57','2023-11-18 19:44:46','1b8b9918-e150-4d4a-8851-e4f8fbe8a8ee'),(11,11,1,'disclaimer','page/disclaimer',1,'2023-11-18 19:44:00','2023-11-18 19:44:00','c281b394-b389-43f9-b2dd-92a08f59dbab'),(12,12,1,'privacy','page/privacy',1,'2023-11-18 19:44:01','2023-11-18 19:44:46','e6029de8-4f7f-4625-ad34-cd93ab8bc615'),(13,13,1,'privacy','page/privacy',1,'2023-11-18 19:44:04','2023-11-18 19:44:04','61d28325-ca01-4d4a-b5de-819f0ccc8769'),(14,14,1,'faq','page/faq',1,'2023-11-18 19:44:05','2023-11-18 19:44:47','8bd83bfb-2990-4eb3-8ce3-476844ef4a59'),(15,15,1,'faq','page/faq',1,'2023-11-18 19:44:08','2023-11-18 19:44:08','326100cb-7bfa-457a-81ea-220af939b7fd'),(16,16,1,'header',NULL,1,'2023-11-18 19:44:20','2023-11-18 19:44:20','49979dee-e5fd-41ca-ac92-1ed8c4471f44'),(18,18,1,'header',NULL,1,'2023-11-18 19:45:28','2023-11-18 19:45:28','2c2537be-6a86-433d-94b1-5eaf1a24509f'),(20,20,1,'header',NULL,1,'2023-11-18 19:46:20','2023-11-18 19:46:20','d805dea1-5143-4104-b036-992fbfb604c9'),(22,22,1,'disclaimer','page/disclaimer',1,'2023-11-18 19:46:51','2023-11-18 19:46:51','f8a6a0c8-67c0-4273-813f-110437856e78'),(23,23,1,'header',NULL,1,'2023-11-18 19:46:57','2023-11-18 19:46:57','7a878d60-f95c-4193-a423-3610d52c7816'),(25,25,1,'header',NULL,1,'2023-11-18 19:47:18','2023-11-18 19:47:18','98184bbd-0e1e-4f7b-948e-e033f8b6956f'),(27,27,1,'disclaimer','page/disclaimer',1,'2023-11-18 19:47:31','2023-11-18 19:47:31','e41e6f14-dda9-41b6-b207-9bc34daa476c'),(28,28,1,'header',NULL,1,'2023-11-18 19:47:32','2023-11-18 19:47:32','e91c30d6-a74a-4ba5-bd46-cab324fbc59f');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tknzioxxpydnpohwknczkiiiujhkkiyuhtem` (`postDate`),
  KEY `idx_xbbnlwozxonmxldxtuldenwmoeiweumdtdjm` (`expiryDate`),
  KEY `idx_ekmvmrfjsdyffcuhofmkwgbeappbjubahfaz` (`authorId`),
  KEY `idx_wokxkebdukwanrjvopvotsfalrjxxghvqgly` (`sectionId`),
  KEY `idx_cxmzhbobkyhcqcjbimrlkwngipidqestndiu` (`typeId`),
  KEY `fk_eppkmpuifewrbwwzdqzmiddtslpybfmrnvly` (`parentId`),
  CONSTRAINT `fk_eppkmpuifewrbwwzdqzmiddtslpybfmrnvly` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mviagfhmwastqhekdvlmwbtuuxlqoxczidrk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vciviylayjxjkxbjhyqkrhftmzhhigmskfoq` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vzwsmyxpvgfdpwxgltcgigkvzxsdbyeixzjd` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zqawjqniufflodentfsyyjlmqpajnaylzikk` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,1,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:42:37','2023-11-18 19:42:37'),(3,1,NULL,1,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:42:37','2023-11-18 19:42:37'),(4,1,NULL,1,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:42:37','2023-11-18 19:42:37'),(5,2,NULL,2,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:42:58','2023-11-18 19:42:58'),(6,2,NULL,2,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:42:58','2023-11-18 19:42:58'),(7,2,NULL,2,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:42:58','2023-11-18 19:42:58'),(8,3,NULL,3,1,'2023-11-18 19:43:00',NULL,NULL,'2023-11-18 19:43:53','2023-11-18 19:43:55'),(9,3,NULL,3,1,'2023-11-18 19:43:00',NULL,NULL,'2023-11-18 19:43:55','2023-11-18 19:43:55'),(10,3,NULL,3,1,'2023-11-18 19:44:00',NULL,NULL,'2023-11-18 19:43:57','2023-11-18 19:44:00'),(11,3,NULL,3,1,'2023-11-18 19:44:00',NULL,NULL,'2023-11-18 19:44:00','2023-11-18 19:44:00'),(12,3,NULL,3,1,'2023-11-18 19:44:00',NULL,NULL,'2023-11-18 19:44:01','2023-11-18 19:44:04'),(13,3,NULL,3,1,'2023-11-18 19:44:00',NULL,NULL,'2023-11-18 19:44:04','2023-11-18 19:44:04'),(14,3,NULL,3,1,'2023-11-18 19:44:00',NULL,NULL,'2023-11-18 19:44:05','2023-11-18 19:44:08'),(15,3,NULL,3,1,'2023-11-18 19:44:00',NULL,NULL,'2023-11-18 19:44:08','2023-11-18 19:44:08'),(16,2,NULL,2,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:44:20','2023-11-18 19:44:20'),(18,2,NULL,2,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:45:28','2023-11-18 19:45:28'),(20,2,NULL,2,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:46:20','2023-11-18 19:46:20'),(22,3,NULL,3,1,'2023-11-18 19:44:00',NULL,NULL,'2023-11-18 19:46:51','2023-11-18 19:46:51'),(23,2,NULL,2,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:46:57','2023-11-18 19:46:57'),(25,2,NULL,2,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:47:18','2023-11-18 19:47:18'),(27,3,NULL,3,1,'2023-11-18 19:44:00',NULL,NULL,'2023-11-18 19:47:31','2023-11-18 19:47:31'),(28,2,NULL,2,NULL,'2023-11-18 19:42:00',NULL,NULL,'2023-11-18 19:47:32','2023-11-18 19:47:32');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yyjwcffpajjiyhroghxdlcchyjoezwsmocbl` (`name`,`sectionId`),
  KEY `idx_jsbqzqhpyrqeumdzpabuhbweoueacuvjcbzq` (`handle`,`sectionId`),
  KEY `idx_etcenhfzpcnjqpuhwasgxwrmgtiyfuddotmb` (`sectionId`),
  KEY `idx_cjqaihwbbkygjuatednoluvnyurguyrdvpgh` (`fieldLayoutId`),
  KEY `idx_liiqiqxgazuxxivjlevwiycwrohdsplcdtyv` (`dateDeleted`),
  CONSTRAINT `fk_jpkmvtjobqbycqsmyvjunhmawtlmwbrhlulc` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zdnjbhkhznsbzxucboxjovdjnkgqxkutmdvz` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,1,'Home','home',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2023-11-18 19:42:36','2023-11-18 19:42:36',NULL,'6a24e78f-0065-47b9-b06f-d48094e94c4b'),(2,2,2,'Header','header',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2023-11-18 19:42:58','2023-11-18 19:42:58',NULL,'c9e7364d-d00e-4a7a-bb8d-92da1ccd7836'),(3,3,3,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2023-11-18 19:43:19','2023-11-18 19:43:19',NULL,'e48e4796-7b9e-4211-aa16-ff37667f872f');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_utwlftpkfrcjbeiixjysfyjlngkzxqwbfpjk` (`name`),
  KEY `idx_hlashioygqqqbmmfzdlqpyczddbnfqmsulti` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES (1,'Common','2023-11-18 19:34:57','2023-11-18 19:34:57',NULL,'51025166-5ea9-48b7-8eff-d1ce65e22831');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gypapfywkrvaxcfmenpjyjmnexalqkewxfgw` (`layoutId`,`fieldId`),
  KEY `idx_yxbslaevomyhrevxcncnwovfogujpwtdurdf` (`sortOrder`),
  KEY `idx_xmstfspyxaedxkdtvammwnemvwytvyojffkp` (`tabId`),
  KEY `idx_jlawuaptzzhmbxgktadktxtomurentwlbtmp` (`fieldId`),
  CONSTRAINT `fk_lwlvaszaqhooncsygzytcoigxhnbbjqoaazy` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oraefflxbouotuizoibwrqwtpynqdjvqheve` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wvzzpmefhqibhwjdwgtuqkdtwqinlsygvrcw` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `fieldlayoutfields` VALUES (1,2,4,1,0,1,'2023-11-18 19:44:20','2023-11-18 19:44:20','01e1bde6-78ad-4525-af08-4003e8d6e66d');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_afyvhfnacxwvivzwjhsyxfotwirmiclwnsxc` (`dateDeleted`),
  KEY `idx_fhotlzzrwzqfqfckoiutxvmyicmtxvnkrzbz` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2023-11-18 19:42:36','2023-11-18 19:42:36',NULL,'da4913b7-7c17-4a57-8d33-d123dd77ae52'),(2,'craft\\elements\\Entry','2023-11-18 19:42:58','2023-11-18 19:42:58',NULL,'deb42fd8-d371-4566-8fc9-296a2aa42626'),(3,'craft\\elements\\Entry','2023-11-18 19:43:19','2023-11-18 19:43:19',NULL,'bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `elements` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wxvnfgdgfcqdyfpiiwvechqlaqvxljcfblux` (`sortOrder`),
  KEY `idx_eqejxlygmkufpjyyjowylblxkwolhzzkqbke` (`layoutId`),
  CONSTRAINT `fk_xxlawayhazkpofqxizgmwlpegqfsickzglre` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `fieldlayouttabs` VALUES (1,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"1d7a76eb-e05e-422d-84fc-22292bdeb087\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-11-18 19:42:36','2023-11-18 19:42:36','edf50a44-070c-40b5-8b12-19d0e188b0b6'),(3,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"a9eed5af-7503-4d62-b04c-8c42cec27c9a\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-11-18 19:43:19','2023-11-18 19:43:19','3533f02f-0f98-49ed-86c9-a63125f49731'),(4,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"bdde76c8-4e6f-45f4-a8ef-69f856bc54c9\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"971195b0-2353-4b17-b37b-8592d4aa8198\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"c2dc6cdf-4e8c-4a6c-b88d-0800be103a93\"}]',1,'2023-11-18 19:44:20','2023-11-18 19:44:20','63b97843-edb4-4fe6-976b-12fdf98fd7b0');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yrjngclnkgfvzxrvqxacpmkfkjuaznjocxex` (`handle`,`context`),
  KEY `idx_rnjxmsefhynldnrdyshfzcyaeiviihwonzsp` (`groupId`),
  KEY `idx_kprihldahymnpncnupuyodvilddmsaflrzli` (`context`),
  CONSTRAINT `fk_wdjommlerlrfuhvfaaucrgiviiyktaooffal` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,1,'Navigation','navigation','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"},\"selectionLabel\":null,\"showSiteMenu\":false,\"sources\":[\"section:7e932b36-6494-4ab0-8508-9d85990c26da\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2023-11-18 19:43:45','2023-11-18 19:43:45','c2dc6cdf-4e8c-4a6c-b88d-0800be103a93');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kdasctcahvadihogzomwczivtuctazdmkhzn` (`name`),
  KEY `idx_bbyzsfixebawduuwdtntfuzhuvwrmpedmmrx` (`handle`),
  KEY `idx_ujwriklhefpzymgkaptpbxmnhrveeqldfgth` (`fieldLayoutId`),
  KEY `idx_tziqaskacpoumgcoqfoaayvofnlkdpkixiwx` (`sortOrder`),
  CONSTRAINT `fk_mdedflzjbbonjvilbejpbewmtrkdgtgdrahd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_svjkgeqrpyreeakyhspccygbueqybojtxjpx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jvefgtojnpbpzuacwccvalsqsmlhmsslsjxi` (`accessToken`),
  UNIQUE KEY `idx_csxdweoleouluyyxpnvtgadebojziskbylny` (`name`),
  KEY `fk_fmoravslmjqmqvjdetqgdrqebopqywtrgmle` (`schemaId`),
  CONSTRAINT `fk_fmoravslmjqmqvjdetqgdrqebopqywtrgmle` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nqomzsefprnndnrwabkmkrliifiztwuqouov` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lfufjqgnycywquywohislcwfdljuqctxssmd` (`name`),
  KEY `idx_gzfrqaovefuxyfisankjjevlbragodbyiuxp` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'4.5.11','4.5.3.0',0,'ylgysxcpswoj','3@ewjiqfgbsg','2023-11-18 19:34:57','2023-11-18 19:46:09','fa1deecc-63e6-48e0-9769-2875afc41fb9');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mfobffwuruufgvhltahsuvtiloghjnzwjuox` (`primaryOwnerId`),
  KEY `idx_cyqdjmllpdyymerbdgybsbiklkcwychnkgus` (`fieldId`),
  KEY `idx_povheyoklnafqfjgqjlgjfmiwbehycfhpvmh` (`typeId`),
  CONSTRAINT `fk_vcsrxhlmhcbsxdnvdhbcashvopoaeocbyczx` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wlsgklacdxospyzhqbwodktzauzrgbgkqxyu` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xugzufqrcwmdiujmyarqpxoxpdqtotzdfpwl` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ynaptpoupbksyxcedtjqymroicemmqatctjp` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_fwxlamnlxyaiykethertioddjvwfmljywkpj` (`ownerId`),
  CONSTRAINT `fk_fwxlamnlxyaiykethertioddjvwfmljywkpj` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sibxhmanigylefwhulptaybwytbuaseckdmm` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_npmhisxtucgippudnzvaclxfaayzhleiscij` (`name`,`fieldId`),
  KEY `idx_eyeenkzakwojedorjglsknxfibputxomilnx` (`handle`,`fieldId`),
  KEY `idx_mukdelqhgjknxrhlkebecgonksdhpluebrei` (`fieldId`),
  KEY `idx_wwbkvjvtnjyspumrrmplivlskrwcettivgth` (`fieldLayoutId`),
  CONSTRAINT `fk_khkuzhjxipqzkfgwxsktzgsdobucwrsjrsie` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ljepnfvbausmbgnznzxbxqzpvibfvknflniz` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zkpbrbmipdszucdcoklpjjqsubjgvbspkhcb` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','a84b4c25-44bc-4eb4-adb1-0e2feb4251f1'),(2,'craft','m210121_145800_asset_indexing_changes','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','69440532-5056-4eec-b7f8-2303e524a88f'),(3,'craft','m210624_222934_drop_deprecated_tables','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','ef602910-16b3-4999-a73f-48b0475081ce'),(4,'craft','m210724_180756_rename_source_cols','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','e203daec-95dc-4ca6-ba07-9df41312eb88'),(5,'craft','m210809_124211_remove_superfluous_uids','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','7b413a17-b00d-4e9f-bdbb-8632e8aebff9'),(6,'craft','m210817_014201_universal_users','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','47424d17-a10b-4b73-b5ed-9f83b120ba07'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','cf91d357-6b06-4afd-92b7-a462f511b773'),(8,'craft','m211115_135500_image_transformers','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','b952635d-e73a-4865-aec0-ca87baffe9fd'),(9,'craft','m211201_131000_filesystems','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','c2b87d4d-9a9e-4f2a-815d-98fda7c0be19'),(10,'craft','m220103_043103_tab_conditions','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','02f5fd2a-595e-4570-9c38-ac590485f059'),(11,'craft','m220104_003433_asset_alt_text','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','73652c84-0b77-4322-8624-0ff82c7c52a0'),(12,'craft','m220123_213619_update_permissions','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','e8f09fcc-1388-46a4-b0e6-6a6b6a5d5f2c'),(13,'craft','m220126_003432_addresses','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','3e932007-aef2-41b7-b932-ea488bf5a442'),(14,'craft','m220209_095604_add_indexes','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','511e8ba2-eaf8-4953-9efe-c66f3ce7b035'),(15,'craft','m220213_015220_matrixblocks_owners_table','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','ebff6623-9d0c-46a3-b06c-9540ec42cdb4'),(16,'craft','m220214_000000_truncate_sessions','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','a93a8eed-e780-4fe8-baad-a0d20a68b043'),(17,'craft','m220222_122159_full_names','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','5c073408-18e9-4370-87cb-b57158657e29'),(18,'craft','m220223_180559_nullable_address_owner','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','5b8d54c4-bcfa-4c20-ab99-4dbf574c6226'),(19,'craft','m220225_165000_transform_filesystems','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','87c21216-39f5-4303-b82d-00448a5d346e'),(20,'craft','m220309_152006_rename_field_layout_elements','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','45d66d1d-befc-491a-898b-7ce9727bfa60'),(21,'craft','m220314_211928_field_layout_element_uids','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','f8076ef5-c03c-4976-a5ea-168a266ceaa3'),(22,'craft','m220316_123800_transform_fs_subpath','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','7b08e3b8-4728-4ab9-aeff-a5e2ba1330aa'),(23,'craft','m220317_174250_release_all_jobs','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','f4af91c9-24b6-4531-a3e2-5500ebdc2f35'),(24,'craft','m220330_150000_add_site_gql_schema_components','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','ce69b6fa-dcfb-48aa-8326-24e7435313e0'),(25,'craft','m220413_024536_site_enabled_string','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','9d704813-346a-4f5f-b251-e6f4ecbbeb04'),(26,'craft','m221027_160703_add_image_transform_fill','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','51eef569-f984-4048-8125-2cf5045be72e'),(27,'craft','m221028_130548_add_canonical_id_index','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','2a1816f3-d072-46bb-b640-b66eaef6b521'),(28,'craft','m221118_003031_drop_element_fks','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','21c91f8c-0881-468d-822d-929c9ab356f6'),(29,'craft','m230131_120713_asset_indexing_session_new_options','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','69eddee8-6958-41c5-b572-0aa2ce4f7d21'),(30,'craft','m230226_013114_drop_plugin_license_columns','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','cd538cf1-038a-400c-b340-aefeb5fc957d'),(31,'craft','m230531_123004_add_entry_type_show_status_field','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','ed55e4ee-22db-4e76-ae84-75b440101fe6'),(32,'craft','m230607_102049_add_entrytype_slug_translation_columns','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','c65cf056-c401-4351-bdc5-a96d3ee05b55'),(33,'craft','m230710_162700_element_activity','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','3e930bcd-76fb-4b32-982d-39c311966a4b'),(34,'craft','m230820_162023_fix_cache_id_type','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','30854640-4fbf-4b79-baa9-4eda01011e3e'),(35,'craft','m230826_094050_fix_session_id_type','2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:34:57','d7006388-4bc1-4723-ae36-8144272dfb02'),(36,'plugin:blitz','Install','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','24055066-2f2e-42d2-8f77-7de16b5ce9d5'),(37,'plugin:blitz','m220330_120000_update_settings','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','2ea5b4a0-54dd-41a4-95c6-ac1c8cc4f710'),(38,'plugin:blitz','m220511_120000_add_hints_table','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','a02c3fe9-b82e-4db7-904e-d160dba487bb'),(39,'plugin:blitz','m220517_120000_add_hints_announcement','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','5bec8270-213b-4a07-99c5-f4a978795a71'),(40,'plugin:blitz','m220630_120000_add_commerce_integration','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','0af9a742-f80f-48bd-8b73-6eca3f1d912e'),(41,'plugin:blitz','m221026_120000_add_include_tables','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','07ebfe38-b49a-4cb2-a81c-70627107ade7'),(42,'plugin:blitz','m230112_120000_add_widget_announcement','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','1766f18f-d3ea-4f6e-9e87-77e150119f78'),(43,'plugin:blitz','m230211_110000_add_elementquery_columns_tables','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','ed7a36da-a915-484f-9091-d67500bcf0b2'),(44,'plugin:blitz','m230211_120000_add_element_fields_columns_tables','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','88e70176-a0e9-4ddb-9564-13f00134cade'),(45,'plugin:blitz','m230705_120000_clear_compressed_cache_if_ssi_or_esi_enabled','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','cd5d717a-f93e-4c82-8cf0-861190f50a9e');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lxeeqrkalrnkgkattoyzdptsjrbctwnzhbqn` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'blitz','4.9.0','4.5.0','2023-11-18 19:37:13','2023-11-18 19:37:13','2023-11-18 19:37:13','f84e1b33-1d37-49e6-a418-4b381640e5d5');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1700336769'),('email.fromEmail','\"andres@voan.ch\"'),('email.fromName','\"Blitz Bug Eager Loading\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elementCondition','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.autocapitalize','true'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.autocomplete','false'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.autocorrect','true'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.class','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.disabled','false'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.elementCondition','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.id','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.instructions','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.label','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.max','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.min','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.name','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.orientation','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.placeholder','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.readonly','false'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.requirable','false'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.size','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.step','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.tip','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.title','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.uid','\"1d7a76eb-e05e-422d-84fc-22292bdeb087\"'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.userCondition','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.warning','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.elements.0.width','100'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.name','\"Content\"'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.uid','\"edf50a44-070c-40b5-8b12-19d0e188b0b6\"'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.fieldLayouts.da4913b7-7c17-4a57-8d33-d123dd77ae52.tabs.0.userCondition','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.handle','\"home\"'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.hasTitleField','false'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.name','\"Home\"'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.section','\"91306678-9101-4cda-9d35-d3705845508d\"'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.showStatusField','true'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.slugTranslationKeyFormat','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.slugTranslationMethod','\"site\"'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.sortOrder','1'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.titleFormat','\"{section.name|raw}\"'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.titleTranslationKeyFormat','null'),('entryTypes.6a24e78f-0065-47b9-b06f-d48094e94c4b.titleTranslationMethod','\"site\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elementCondition','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.autocapitalize','true'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.autocomplete','false'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.autocorrect','true'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.class','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.disabled','false'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.elementCondition','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.id','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.instructions','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.label','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.max','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.min','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.name','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.orientation','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.placeholder','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.readonly','false'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.requirable','false'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.size','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.step','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.tip','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.title','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.uid','\"bdde76c8-4e6f-45f4-a8ef-69f856bc54c9\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.userCondition','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.warning','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.0.width','100'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.elementCondition','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.fieldUid','\"c2dc6cdf-4e8c-4a6c-b88d-0800be103a93\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.instructions','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.label','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.required','false'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.tip','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.uid','\"971195b0-2353-4b17-b37b-8592d4aa8198\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.userCondition','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.warning','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.elements.1.width','100'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.name','\"Content\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.uid','\"63b97843-edb4-4fe6-976b-12fdf98fd7b0\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.fieldLayouts.deb42fd8-d371-4566-8fc9-296a2aa42626.tabs.0.userCondition','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.handle','\"header\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.hasTitleField','false'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.name','\"Header\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.section','\"b5276cbb-dff1-43ec-8bd6-5d4787b5f93b\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.showStatusField','true'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.slugTranslationKeyFormat','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.slugTranslationMethod','\"site\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.sortOrder','1'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.titleFormat','\"{section.name|raw}\"'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.titleTranslationKeyFormat','null'),('entryTypes.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836.titleTranslationMethod','\"site\"'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elementCondition','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.autocapitalize','true'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.autocomplete','false'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.autocorrect','true'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.class','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.disabled','false'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.elementCondition','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.id','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.instructions','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.label','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.max','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.min','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.name','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.orientation','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.placeholder','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.readonly','false'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.requirable','false'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.size','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.step','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.tip','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.title','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.uid','\"a9eed5af-7503-4d62-b04c-8c42cec27c9a\"'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.userCondition','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.warning','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.elements.0.width','100'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.name','\"Content\"'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.uid','\"3533f02f-0f98-49ed-86c9-a63125f49731\"'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.fieldLayouts.bbcb38d8-79ed-47e8-84d4-0423fb4ec6f5.tabs.0.userCondition','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.handle','\"default\"'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.hasTitleField','true'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.name','\"Default\"'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.section','\"7e932b36-6494-4ab0-8508-9d85990c26da\"'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.showStatusField','true'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.slugTranslationKeyFormat','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.slugTranslationMethod','\"site\"'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.sortOrder','1'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.titleFormat','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.titleTranslationKeyFormat','null'),('entryTypes.e48e4796-7b9e-4211-aa16-ff37667f872f.titleTranslationMethod','\"site\"'),('fieldGroups.51025166-5ea9-48b7-8eff-d1ce65e22831.name','\"Common\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.columnSuffix','null'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.contentColumnType','\"string\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.fieldGroup','\"51025166-5ea9-48b7-8eff-d1ce65e22831\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.handle','\"navigation\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.instructions','null'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.name','\"Navigation\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.searchable','false'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.allowSelfRelations','false'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.branchLimit','null'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.localizeRelations','false'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.maintainHierarchy','false'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.maxRelations','null'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.minRelations','null'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Entry\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.selectionLabel','null'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.showSiteMenu','false'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.sources.0','\"section:7e932b36-6494-4ab0-8508-9d85990c26da\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.targetSiteId','null'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.validateRelatedElements','false'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.settings.viewMode','null'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.translationKeyFormat','null'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.translationMethod','\"site\"'),('fields.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93.type','\"craft\\\\fields\\\\Entries\"'),('meta.__names__.3b45e539-7b30-4421-9bfe-f319cd7f9794','\"Blitz Bug Eager Loading\"'),('meta.__names__.51025166-5ea9-48b7-8eff-d1ce65e22831','\"Common\"'),('meta.__names__.6a24e78f-0065-47b9-b06f-d48094e94c4b','\"Home\"'),('meta.__names__.7e932b36-6494-4ab0-8508-9d85990c26da','\"Page\"'),('meta.__names__.91306678-9101-4cda-9d35-d3705845508d','\"Home\"'),('meta.__names__.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b','\"Header\"'),('meta.__names__.c2dc6cdf-4e8c-4a6c-b88d-0800be103a93','\"Navigation\"'),('meta.__names__.c9e7364d-d00e-4a7a-bb8d-92da1ccd7836','\"Header\"'),('meta.__names__.e48e4796-7b9e-4211-aa16-ff37667f872f','\"Default\"'),('meta.__names__.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9','\"Blitz Bug Eager Loading\"'),('plugins.blitz.edition','\"standard\"'),('plugins.blitz.enabled','true'),('plugins.blitz.licenseKey','\"UH9VBW33J6OD3BH5E7KQGPLY\"'),('plugins.blitz.schemaVersion','\"4.5.0\"'),('plugins.blitz.settings.apiKey','\"\"'),('plugins.blitz.settings.cacheControlHeader','\"public, s-maxage=31536000, max-age=0\"'),('plugins.blitz.settings.cacheControlHeaderExpired','\"public, s-maxage=5, max-age=0\"'),('plugins.blitz.settings.cacheDuration','null'),('plugins.blitz.settings.cacheElementQueries','true'),('plugins.blitz.settings.cacheElements','true'),('plugins.blitz.settings.cacheGeneratorSettings.__assoc__.0.0','\"concurrency\"'),('plugins.blitz.settings.cacheGeneratorSettings.__assoc__.0.1','\"3\"'),('plugins.blitz.settings.cacheGeneratorType','\"putyourlightson\\\\blitz\\\\drivers\\\\generators\\\\HttpGenerator\"'),('plugins.blitz.settings.cacheNonHtmlResponses','false'),('plugins.blitz.settings.cachePurgerType','\"putyourlightson\\\\blitz\\\\drivers\\\\purgers\\\\DummyPurger\"'),('plugins.blitz.settings.cacheStorageSettings.__assoc__.0.0','\"folderPath\"'),('plugins.blitz.settings.cacheStorageSettings.__assoc__.0.1','\"@webroot/cache/blitz\"'),('plugins.blitz.settings.cacheStorageSettings.__assoc__.1.0','\"compressCachedValues\"'),('plugins.blitz.settings.cacheStorageSettings.__assoc__.1.1','\"1\"'),('plugins.blitz.settings.cacheStorageType','\"putyourlightson\\\\blitz\\\\drivers\\\\storage\\\\FileStorage\"'),('plugins.blitz.settings.cachingEnabled','true'),('plugins.blitz.settings.debug','false'),('plugins.blitz.settings.defaultCacheControlHeader','\"no-cache, no-store, must-revalidate\"'),('plugins.blitz.settings.deployerType','\"putyourlightson\\\\blitz\\\\drivers\\\\deployers\\\\DummyDeployer\"'),('plugins.blitz.settings.driverJobPriority','100'),('plugins.blitz.settings.esiEnabled','false'),('plugins.blitz.settings.excludedQueryStringParams.0.__assoc__.0.0','\"queryStringParam\"'),('plugins.blitz.settings.excludedQueryStringParams.0.__assoc__.0.1','\"gclid\"'),('plugins.blitz.settings.excludedQueryStringParams.1.__assoc__.0.0','\"queryStringParam\"'),('plugins.blitz.settings.excludedQueryStringParams.1.__assoc__.0.1','\"fbclid\"'),('plugins.blitz.settings.generatePagesWithQueryStringParams','true'),('plugins.blitz.settings.hintsEnabled','true'),('plugins.blitz.settings.includedQueryStringParams.0.__assoc__.0.0','\"queryStringParam\"'),('plugins.blitz.settings.includedQueryStringParams.0.__assoc__.0.1','\".*\"'),('plugins.blitz.settings.includedUriPatterns.0.__assoc__.0.0','\"uriPattern\"'),('plugins.blitz.settings.includedUriPatterns.0.__assoc__.0.1','\".*\"'),('plugins.blitz.settings.injectScriptEvent','\"DOMContentLoaded\"'),('plugins.blitz.settings.integrations.0','\"putyourlightson\\\\blitz\\\\drivers\\\\integrations\\\\CommerceIntegration\"'),('plugins.blitz.settings.integrations.1','\"putyourlightson\\\\blitz\\\\drivers\\\\integrations\\\\FeedMeIntegration\"'),('plugins.blitz.settings.integrations.2','\"putyourlightson\\\\blitz\\\\drivers\\\\integrations\\\\SeomaticIntegration\"'),('plugins.blitz.settings.maxRetryAttempts','10'),('plugins.blitz.settings.maxUriLength','255'),('plugins.blitz.settings.mutexTimeout','1'),('plugins.blitz.settings.outputComments','true'),('plugins.blitz.settings.purgeAssetImagesWhenChanged','true'),('plugins.blitz.settings.queryStringCaching','0'),('plugins.blitz.settings.queueJobTtr','300'),('plugins.blitz.settings.refreshCacheAutomaticallyForGlobals','true'),('plugins.blitz.settings.refreshCacheJobPriority','10'),('plugins.blitz.settings.refreshCacheWhenElementMovedInStructure','true'),('plugins.blitz.settings.refreshCacheWhenElementSavedNotLive','false'),('plugins.blitz.settings.refreshCacheWhenElementSavedUnchanged','false'),('plugins.blitz.settings.refreshMode','3'),('plugins.blitz.settings.sendPoweredByHeader','true'),('plugins.blitz.settings.ssiEnabled','false'),('plugins.blitz.settings.trackElementQueries','true'),('plugins.blitz.settings.trackElements','true'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.defaultPlacement','\"end\"'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.enableVersioning','true'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.handle','\"page\"'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.name','\"Page\"'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.propagationMethod','\"all\"'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.enabledByDefault','true'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.hasUrls','true'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.template','\"page/_entry\"'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.uriFormat','\"page/{slug}\"'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.structure.maxLevels','null'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.structure.uid','\"273007a8-49ab-42c2-8c46-4e9f8dda31e0\"'),('sections.7e932b36-6494-4ab0-8508-9d85990c26da.type','\"structure\"'),('sections.91306678-9101-4cda-9d35-d3705845508d.defaultPlacement','\"end\"'),('sections.91306678-9101-4cda-9d35-d3705845508d.enableVersioning','true'),('sections.91306678-9101-4cda-9d35-d3705845508d.handle','\"home\"'),('sections.91306678-9101-4cda-9d35-d3705845508d.name','\"Home\"'),('sections.91306678-9101-4cda-9d35-d3705845508d.propagationMethod','\"all\"'),('sections.91306678-9101-4cda-9d35-d3705845508d.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.enabledByDefault','true'),('sections.91306678-9101-4cda-9d35-d3705845508d.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.hasUrls','true'),('sections.91306678-9101-4cda-9d35-d3705845508d.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.template','\"home/_entry\"'),('sections.91306678-9101-4cda-9d35-d3705845508d.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.uriFormat','\"__home__\"'),('sections.91306678-9101-4cda-9d35-d3705845508d.type','\"single\"'),('sections.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b.defaultPlacement','\"end\"'),('sections.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b.enableVersioning','true'),('sections.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b.handle','\"header\"'),('sections.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b.name','\"Header\"'),('sections.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b.propagationMethod','\"all\"'),('sections.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.enabledByDefault','true'),('sections.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.hasUrls','false'),('sections.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.template','null'),('sections.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b.siteSettings.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.uriFormat','null'),('sections.b5276cbb-dff1-43ec-8bd6-5d4787b5f93b.type','\"single\"'),('siteGroups.3b45e539-7b30-4421-9bfe-f319cd7f9794.name','\"Blitz Bug Eager Loading\"'),('sites.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.handle','\"default\"'),('sites.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.hasUrls','true'),('sites.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.language','\"en\"'),('sites.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.name','\"Blitz Bug Eager Loading\"'),('sites.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.primary','true'),('sites.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.siteGroup','\"3b45e539-7b30-4421-9bfe-f319cd7f9794\"'),('sites.f77f2823-75d2-4434-bf3e-9b5cb6a46fc9.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Blitz Bug Eager Loading\"'),('system.schemaVersion','\"4.5.3.0\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_ricxrxsiadybdpntyddhjcrbgagftpibapgn` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_esnmmjnhzioswvjxuyckdpnhbpebehfnbxcu` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_huvqgzudnvvppfguvnciisawiywxbsrrieor` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_ckwrucqgnkfmdsqwjjdbfiiuzdhxgcgrppet` (`sourceId`),
  KEY `idx_gyvwznrpweaalykghmvldavoqgzmhoqaiuub` (`targetId`),
  KEY `idx_weddywzdrlfscuwdyxvtziommtfngdemfuiz` (`sourceSiteId`),
  CONSTRAINT `fk_emhzblimzbqghedyyyfoqepojbnakubgrkrl` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fbweacwsapmjixvboaklexqtztskydjqhbxn` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hdxbsxqmtinvzegqsotqdlemromcyjeqjnto` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (3,1,5,NULL,10,1,'2023-11-18 19:45:28','2023-11-18 19:45:28','f4f9b763-a28b-4d83-b23e-baf5d7cd1c85'),(5,1,18,NULL,10,1,'2023-11-18 19:45:28','2023-11-18 19:45:28','da052095-50a1-411b-abdc-21b48f20925a'),(6,1,18,NULL,12,2,'2023-11-18 19:45:28','2023-11-18 19:45:28','74391bc8-5c54-4221-af06-0be224844cee'),(9,1,20,NULL,10,1,'2023-11-18 19:46:20','2023-11-18 19:46:20','20bea308-1802-4587-bedc-131401d8e993'),(10,1,23,NULL,10,1,'2023-11-18 19:46:57','2023-11-18 19:46:57','4b2666a6-4cd2-4b3c-b229-c761c6c28e68'),(13,1,5,NULL,12,2,'2023-11-18 19:47:18','2023-11-18 19:47:18','34fc864a-6411-488c-8c5f-ef3f34f2dc0c'),(14,1,25,NULL,10,1,'2023-11-18 19:47:18','2023-11-18 19:47:18','1e8860ca-4833-4c64-874d-0de3c84a861e'),(15,1,25,NULL,12,2,'2023-11-18 19:47:18','2023-11-18 19:47:18','de53e291-d556-4a03-a2c1-69e581d60b0f'),(16,1,28,NULL,10,1,'2023-11-18 19:47:32','2023-11-18 19:47:32','62f0a770-95f6-485e-adb3-7e7159e4af99'),(17,1,28,NULL,12,2,'2023-11-18 19:47:32','2023-11-18 19:47:32','f888438d-7313-4ea5-8e9c-92c287cbc2a4');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('1113543f','@craft/web/assets/cp/dist'),('18686442','@craft/web/assets/pluginstore/dist'),('1a4e4c55','@craft/web/assets/tailwindreset/dist'),('1c6f0fe9','@craft/web/assets/installer/dist'),('1cc0c25','@putyourlightson/blitz/resources/images'),('1d5bf677','@craft/web/assets/selectize/dist'),('2d225a99','@craft/web/assets/axios/dist'),('35d7cfc0','@craft/web/assets/recententries/dist'),('3650a794','@craft/web/assets/conditionbuilder/dist'),('3c14899f','@craft/web/assets/updater/dist'),('477bc1','@craft/web/assets/iframeresizer/dist'),('4be16cf5','@craft/web/assets/utilities/dist'),('4c0296d5','@craft/web/assets/queuemanager/dist'),('5539fed6','@craft/web/assets/sites/dist'),('5bcbfacb','@craft/web/assets/fabric/dist'),('62eaef7','@craft/web/assets/fieldsettings/dist'),('62f78e23','@craft/web/assets/admintable/dist'),('6bd976f6','@craft/web/assets/fields/dist'),('7379cddc','@craft/web/assets/garnish/dist'),('88a9e10e','@craft/web/assets/editsection/dist'),('88f11151','@craft/web/assets/vue/dist'),('93cd869b','@craft/web/assets/clearcaches/dist'),('93d446e3','@craft/web/assets/feed/dist'),('974d427a','@craft/web/assets/datepickeri18n/dist'),('991514df','@craft/web/assets/jquerytouchevents/dist'),('9946cbbd','@craft/web/assets/jquerypayment/dist'),('9b0c6c9c','@putyourlightson/blitz/resources'),('9cd1c90a','@craft/web/assets/velocity/dist'),('a4c7cc6a','@craft/web/assets/login/dist'),('a51d1163','@craft/web/assets/picturefill/dist'),('aa6fe1df','@craft/web/assets/timepicker/dist'),('acc17ba7','@craft/web/assets/craftsupport/dist'),('aea5ac63','@craft/web/assets/xregexp/dist'),('b267276','@craft/web/assets/d3/dist'),('b6d8dae','@craft/web/assets/updateswidget/dist'),('c50ff063','@craft/web/assets/jqueryui/dist'),('ca087f9d','@craft/web/assets/elementresizedetector/dist'),('cfe86075','@bower/jquery/dist'),('db7426c8','@craft/web/assets/fileupload/dist'),('ea976028','@craft/web/assets/dashboard/dist'),('fe41e2a7','@craft/web/assets/htmx/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bezedxrdgcnrbjjnuvrsmmtfbvxrceaxfxrh` (`canonicalId`,`num`),
  KEY `fk_rrjmqehpumwrtihefhupmkaaavuuijspxhee` (`creatorId`),
  CONSTRAINT `fk_ojintzndedqhkonchrerxrwvjhhybocfbnxb` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rrjmqehpumwrtihefhupmkaaavuuijspxhee` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,2,1,2,NULL),(3,5,1,1,NULL),(4,5,1,2,NULL),(5,8,1,1,''),(6,10,1,1,''),(7,12,1,1,''),(8,14,1,1,''),(9,5,1,3,NULL),(10,5,1,4,'Applied “Draft 1”'),(11,5,1,5,'Applied “Draft 1”'),(12,10,1,2,'Applied “Draft 1”'),(13,5,1,6,''),(14,5,1,7,'Applied “Draft 1”'),(15,10,1,3,'Applied “Draft 1”'),(16,5,1,8,'');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_oglacnhyywofenaxnfqddzxavkcpjzrowrfm` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' andres voan ch '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'slug',0,1,' home '),(2,'title',0,1,' home '),(5,'slug',0,1,' header '),(5,'title',0,1,' header '),(8,'slug',0,1,' terms '),(8,'title',0,1,' terms '),(10,'slug',0,1,' disclaimer '),(10,'title',0,1,' disclaimer '),(12,'slug',0,1,' privacy '),(12,'title',0,1,' privacy '),(14,'slug',0,1,' faq '),(14,'title',0,1,' faq ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eytsozefaliojazzvuxzuopuybacnbrsffho` (`handle`),
  KEY `idx_srbffgvvgafdnzjexgdceronytedwqgfkkqh` (`name`),
  KEY `idx_nrmxjwsnrghcmyqvdvqldeefcssmgyduxfzw` (`structureId`),
  KEY `idx_crjhvhbhtfjhvcfzwtvuiomrwxehhfklxdqp` (`dateDeleted`),
  CONSTRAINT `fk_nafnduqlffkgvjdfvztkwsezeiqxseyxahle` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Home','home','single',1,'all','end',NULL,'2023-11-18 19:42:36','2023-11-18 19:42:36',NULL,'91306678-9101-4cda-9d35-d3705845508d'),(2,NULL,'Header','header','single',1,'all','end',NULL,'2023-11-18 19:42:58','2023-11-18 19:42:58',NULL,'b5276cbb-dff1-43ec-8bd6-5d4787b5f93b'),(3,1,'Page','page','structure',1,'all','end',NULL,'2023-11-18 19:43:19','2023-11-18 19:43:19',NULL,'7e932b36-6494-4ab0-8508-9d85990c26da');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cccgvvstiqgmvpykipuxbuvodlacncxhyihj` (`sectionId`,`siteId`),
  KEY `idx_nirbaacwkyrzyywfemtkbojzuoukvotoizcd` (`siteId`),
  CONSTRAINT `fk_weswjizfvbckxsmxpqsdygwcsyjdhflcyguq` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zopkgkgbpusqzjtqllwnzgqwwmiriabeprwy` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','home/_entry',1,'2023-11-18 19:42:36','2023-11-18 19:42:36','d9f9c50d-f4ed-415e-bbed-968c0bca48c8'),(2,2,1,0,NULL,NULL,1,'2023-11-18 19:42:58','2023-11-18 19:42:58','3616816d-7a2b-432a-bde3-8e154fc23021'),(3,3,1,1,'page/{slug}','page/_entry',1,'2023-11-18 19:43:19','2023-11-18 19:43:19','2904b88a-f4da-46e9-8af8-6a71c2a7926d');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vegipfgcnmblnaeuflbuqlkqnmbnqprrnshb` (`uid`),
  KEY `idx_vdooucejkfnidhvkknkjzostrruhfuovhhcu` (`token`),
  KEY `idx_etdkrhsznwsasejysoqfkobhyopzytjeyoin` (`dateUpdated`),
  KEY `idx_sbyfwswwbcrtqiprnvbivzvhavglypadgtyk` (`userId`),
  CONSTRAINT `fk_yyvjpajpqsuwamdhzsvlxdcvtlhdeutmbxng` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'lXa8UMaBnIlDkBhMYEPA4CwfGGvF0yfuv06V7su891YkEtoxkjNVn5CGBkS1F1jJNTqU005VUwtFgk2CzFWAgcrZ-xRTy_NMwmON','2023-11-18 19:36:24','2023-11-18 19:48:33','2b5bfe20-6497-4964-95ef-73d2058e06cb');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yyyelmyngoqctvrqeapqbtdgqxteopcamdqd` (`userId`,`message`),
  CONSTRAINT `fk_pucbplhjgcogkiyxexftnhjmzvzpefvdmocx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ysrbhtnsypqzxebmoeecungzabxircyluzyd` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Blitz Bug Eager Loading','2023-11-18 19:34:57','2023-11-18 19:34:57',NULL,'3b45e539-7b30-4421-9bfe-f319cd7f9794');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dhsfzizmfivvxlyezpwcwrdldlbhxrqziove` (`dateDeleted`),
  KEY `idx_fhrlalhxjpgymagsctbyeetevqnzdkafzjkl` (`handle`),
  KEY `idx_hadxtkzsfohjeuafcronkzkassixbjgobqou` (`sortOrder`),
  KEY `fk_ivaejfevjynvvosjyoaqqubqjqhjoxtthnxj` (`groupId`),
  CONSTRAINT `fk_ivaejfevjynvvosjyoaqqubqjqhjoxtthnxj` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','Blitz Bug Eager Loading','default','en',1,'$PRIMARY_SITE_URL',1,'2023-11-18 19:34:57','2023-11-18 19:34:57',NULL,'f77f2823-75d2-4434-bf3e-9b5cb6a46fc9');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pjoswkgnvbhtqcygvnnmlcyrbpivahthgeji` (`structureId`,`elementId`),
  KEY `idx_otopwyjvhddmunqmwdwfkcgqxgbwxkupizaf` (`root`),
  KEY `idx_cpocgjogelkssnmesxffojayfkozsgjeyjge` (`lft`),
  KEY `idx_lfawpxrwtjvryadqddynrryndbmyiqiwmddl` (`rgt`),
  KEY `idx_sqkvqthhvfzndxsdhrihkwufvylngvxdndup` (`level`),
  KEY `idx_vvntyeyxdnohodehpazyuzqwrbkpwevoobhn` (`elementId`),
  CONSTRAINT `fk_wyktmjrtecyntejvhlffioxlrekmnozjqdzi` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,10,0,'2023-11-18 19:43:53','2023-11-18 19:44:05','3bf510e3-6b81-4837-a66d-700a9e937bc0'),(2,1,8,1,2,3,1,'2023-11-18 19:43:53','2023-11-18 19:43:53','1ed2b89b-b249-4716-ba2a-1a195a72bf9c'),(3,1,10,1,4,5,1,'2023-11-18 19:43:57','2023-11-18 19:43:57','bd46fc2a-986d-4a5d-9490-91b1e190dce1'),(4,1,12,1,6,7,1,'2023-11-18 19:44:01','2023-11-18 19:44:01','46729832-2299-49fe-b5b3-371187066db4'),(5,1,14,1,8,9,1,'2023-11-18 19:44:05','2023-11-18 19:44:05','12f09804-bdef-4673-85f0-10265a476854');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ayesmtbjmelqtavdwfbntjebxrwcqqmexore` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,NULL,'2023-11-18 19:43:19','2023-11-18 19:43:19',NULL,'273007a8-49ab-42c2-8c46-4e9f8dda31e0');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fxmtfzaobpoqatcueqstumodzpfgktwsnssl` (`key`,`language`),
  KEY `idx_xvgrrdthpctlpiqkhabjrpqxypjscjzsrgmz` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wnegpdvadwsivodjokabmvawtjningzaykmi` (`name`),
  KEY `idx_fpiascgmvmitcxtqtoxhvytemycozdtnrlmu` (`handle`),
  KEY `idx_jzqryhrebuaiwatgvzigjgagaeawlqvmwmoc` (`dateDeleted`),
  KEY `fk_uejmsuhnxqpnbuavaucqnstzeykzmialpzmk` (`fieldLayoutId`),
  CONSTRAINT `fk_uejmsuhnxqpnbuavaucqnstzeykzmialpzmk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ukzvvmtdcjqzcilrwxyctsfhknnnpaocslms` (`groupId`),
  CONSTRAINT `fk_mcwbkmstcffcjsvdcczkkbvmaycvcthowtoz` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pfapgclzpsqoonxarcpchuifpaknxiwkqcyu` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mlchlqlrkrlkgfbaddwfumigbzlksjfpfvnw` (`token`),
  KEY `idx_hzxjbkciqytgueskrfwzwmgjzsrukhwiodwn` (`expiryDate`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,'qLAHP4FTGODxAkmjAkMbUEP0AHWhVZEI','blitz/generator/generate',NULL,NULL,'2023-11-19 19:44:45','2023-11-18 19:44:45','2023-11-18 19:44:45','9c5a042a-5320-42e2-be0c-fb869831e0c8'),(2,'M2q611yvRudeqByM9jUkbqiCIBTqfdLL','blitz/generator/generate',NULL,NULL,'2023-11-19 19:44:45','2023-11-18 19:44:45','2023-11-18 19:44:45','ad70e079-04b4-473b-91ea-1725896d4186'),(3,'83mS63ODy8-LZDbWz5r6HSmlix17R9ip','blitz/generator/generate',NULL,NULL,'2023-11-19 19:44:45','2023-11-18 19:44:45','2023-11-18 19:44:45','6b8dfa30-1578-4f4c-9ba3-25e1814cf558'),(4,'g2oiVVjXlEVqTElntYoHR_GV1b0nXPSo','blitz/generator/generate',NULL,NULL,'2023-11-19 19:44:45','2023-11-18 19:44:46','2023-11-18 19:44:46','a6a339c5-a727-44e8-8da2-2eff589ea16d'),(5,'RU3WPVvjKy7toj33L_nLSw5e8Jms9E9S','blitz/generator/generate',NULL,NULL,'2023-11-19 19:44:46','2023-11-18 19:44:46','2023-11-18 19:44:46','467e3efd-2775-4033-b26d-d77a603eb112'),(6,'ELxTYiN4Jm_8W7iyzwliurLUJHn37Jot','blitz/generator/generate',NULL,NULL,'2023-11-19 19:44:46','2023-11-18 19:44:46','2023-11-18 19:44:46','d907eecf-190a-4098-8bd2-6003bc10b172'),(7,'6tf5tWfNshAbyO721sFCqn7OGf__RH6i','blitz/generator/generate',NULL,NULL,'2023-11-19 19:45:31','2023-11-18 19:45:31','2023-11-18 19:45:31','54f2a199-19dc-4a33-92b9-2121825935d5'),(8,'xxbWtvuG2ocZLzNuw8IkovsqzdJG0hG6','blitz/generator/generate',NULL,NULL,'2023-11-19 19:46:26','2023-11-18 19:46:26','2023-11-18 19:46:26','ee78ab54-4b5d-4a37-8c83-4d99b9c84830'),(9,'hfD2gKbznAXt4aCP4QZtMJdiXndtaQik','blitz/generator/generate',NULL,NULL,'2023-11-19 19:47:03','2023-11-18 19:47:03','2023-11-18 19:47:03','1dfa701d-c8a8-4679-99c6-8229a7aff495'),(10,'ECdvjJOsVk-ncm9tozuAiVnUjHv_cq2m','blitz/generator/generate',NULL,NULL,'2023-11-19 19:47:23','2023-11-18 19:47:23','2023-11-18 19:47:23','5d77bd1e-5c5b-420a-8005-d6902419ea95'),(11,'iMHSi50DzChjLHEvCHbZgWfRlNeZ_Orm','blitz/generator/generate',NULL,NULL,'2023-11-19 19:47:51','2023-11-18 19:47:51','2023-11-18 19:47:51','73a6ba36-c1c8-41ff-8619-70235247c51e');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fahgnpxreojfiunrkctpgyqknxwapfntflai` (`handle`),
  KEY `idx_lxnxisnulgexjvornyogifzonixsxusxjqxm` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xljhsoctgipwbttlublsjztpwixcstlkjray` (`groupId`,`userId`),
  KEY `idx_fjvsgluvhrtkkjualjvjirzwiiqssrjyoofg` (`userId`),
  CONSTRAINT `fk_lhoaljettyaoxxrwknjtnkbtwvrolsuopdrk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xrsedkmwmcxpiksyozqrefpyascxvycokgzx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uxxhrjydvppfjzwusooihfgewmvuhxblximk` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_paordcxeergigfgacrcgzhsagepkotbfzytv` (`permissionId`,`groupId`),
  KEY `idx_gnpfkolpfrkldshxdkmssnsjcyhytpthdain` (`groupId`),
  CONSTRAINT `fk_ekzhhpmulystbmewqlhdymkpknxjdjinrfan` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pvdzrqyjdnkszcelvsaaovenxinesalthgcx` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_syutycvryawqopueoluyyvlrsljjqmqxiuhn` (`permissionId`,`userId`),
  KEY `idx_hvpkebobtfgikwubtmufemesnumpentwsjtv` (`userId`),
  CONSTRAINT `fk_dmhprguhjbmyaqumytadvezsnqhfffmggrzx` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nbhturfemzxlzgwrtcmcpdhiguwqgmhvvvhg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_dlnzabujihemlxfokpfgsfvumsxcpmiijend` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vakmzoseyastfpihykjdsrxzxwucrcqjcqov` (`active`),
  KEY `idx_hqxpbbgstfnkfebwvkahuatjpkcdhcbesilp` (`locked`),
  KEY `idx_fncrjffxgjevxdaupvsvrekyycfqxxsqgvfy` (`pending`),
  KEY `idx_mtjgpypfszsupybfpfyfizwoxbktktqhrsap` (`suspended`),
  KEY `idx_xolsgftxujvfxvshihnciqhnitgjqjwldjmi` (`verificationCode`),
  KEY `idx_fiimfujmlvdyulqvfngbrabainmnpyzeaaxj` (`email`),
  KEY `idx_ekezojgeouulyulnetdekjcbrqrzgrhyfoji` (`username`),
  KEY `fk_bzbdekewnqogqcjtnjlttwsvivnekzabrepd` (`photoId`),
  CONSTRAINT `fk_bzbdekewnqogqcjtnjlttwsvivnekzabrepd` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xkxmfwsuuowjtfkajauxmtsutfgauydqhhlg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'andres@voan.ch','$2y$13$zx6wSdoYddCa/HFV93.OneYlc9bmolZb33cHtpQb7WvlP7b9Zf/OO','2023-11-18 19:36:24',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2023-11-18 19:34:57','2023-11-18 19:34:57','2023-11-18 19:36:24');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fgfywldwbswfguvywrrhcccnjixkpyfzxsyt` (`name`,`parentId`,`volumeId`),
  KEY `idx_fluadsusaixiyunsthslugsijcsldoxqikqb` (`parentId`),
  KEY `idx_htiwawtikbhgqyyjvdjiprdxdsryqdbdkpde` (`volumeId`),
  CONSTRAINT `fk_gkpmszowhmnxwmowjehimogojpiaixekgzbz` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rcuqecxtiutjgvbbdnagdadxyfurngvwtmev` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_crltkwrzwemmskzsclwcjqzhkeomzftehwjf` (`name`),
  KEY `idx_wpmkejhpmaikvspbeccoidzrrhpkjmdkgcig` (`handle`),
  KEY `idx_tibkuajudtvasqcwyotlkhkccfbpvdmvpqwh` (`fieldLayoutId`),
  KEY `idx_ekpuqswgqwftvmwvlnyplohnioxqvkxjipyu` (`dateDeleted`),
  CONSTRAINT `fk_zdkdctogprgpcqwtafwpoaegpcfwtptqabjy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yzeqetzzhwiyzymmdxaxofklflgcurcxsxyu` (`userId`),
  CONSTRAINT `fk_zanacyshckptvypbcdvttwvjozbnxvhehifp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2023-11-18 19:36:24','2023-11-18 19:36:24','6c2d9461-8e00-4c83-8b56-6f699992fa2e'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2023-11-18 19:36:24','2023-11-18 19:36:24','412ede68-4541-4e96-abf1-2c70135398ac'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2023-11-18 19:36:24','2023-11-18 19:36:24','fb2da441-3b18-4081-88bc-f0bfd7039e91'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2023-11-18 19:36:24','2023-11-18 19:36:24','44ad17ef-a57a-4360-a1bb-519fa9e099ee');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-18 19:49:19
